package com.java.ajay.springboot.controller;

import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

@RestController
public class HomeController {

    @GetMapping("/")
    public String home() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("home");
        return "<h2>Welcome To Spring Boot Web</h2>" +
                "<p> Go to <a href = '/home'><b>Home</b></a></p>";
    }

    @GetMapping("/home")
    public ModelAndView home(ModelAndView modelAndView) {
        modelAndView.setViewName("home");
        modelAndView.addObject("name", "AJAY-SINGH MEENA");
        return modelAndView;
    }

    @GetMapping(value = "/get-token")
    public CsrfToken getToken(HttpServletRequest request) {
        return (CsrfToken) request.getAttribute("_csrf");
    }
}
