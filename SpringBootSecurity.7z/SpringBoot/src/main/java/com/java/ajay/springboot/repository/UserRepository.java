package com.java.ajay.springboot.repository;

import com.java.ajay.springboot.model.User;
import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<User, Long> {
}
