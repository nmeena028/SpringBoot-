package com.java.ajay.springboot.handler;

import com.java.ajay.springboot.exception.ApiResponse;
import com.java.ajay.springboot.exception.EmployeeNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class ExceptionAdviceController {

    @ExceptionHandler(EmployeeNotFoundException.class)
    public ResponseEntity<ApiResponse> handleException(EmployeeNotFoundException ex) {
        String errorMsg = ex.getMessage();
        ApiResponse apiResponse = new ApiResponse(errorMsg, 404, "Not Found");
        return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse> globalExceptionHandler(Exception ex, WebRequest request) {
        String errorMsg = ex.getMessage();
        ApiResponse apiResponse = new ApiResponse(errorMsg, 500, request.getDescription(false));
        return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
