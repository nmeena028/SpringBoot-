package com.java.ajay.springboot.repository;

import com.java.ajay.springboot.model.UserLogin;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface UserLoginRepository extends CrudRepository<UserLogin, Long> {
    UserLogin findByUserName(String username);
    //insert into USER_LOGIN (user_id, user_name, password) values (1, 'meenaja', 'xxx222');

    @Query("SELECT MAX(e.userId) FROM UserLogin e")
    Optional<Long> findMaxUserId();
}
