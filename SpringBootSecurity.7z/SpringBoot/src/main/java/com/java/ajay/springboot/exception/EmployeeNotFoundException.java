package com.java.ajay.springboot.exception;

public class EmployeeNotFoundException extends RuntimeException {
    public EmployeeNotFoundException(String error) {
        super(error);
    }
}
