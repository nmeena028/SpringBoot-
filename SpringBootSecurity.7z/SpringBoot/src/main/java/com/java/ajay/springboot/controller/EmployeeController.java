package com.java.ajay.springboot.controller;

import com.java.ajay.springboot.model.Employee;
import com.java.ajay.springboot.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @Cacheable(value = "employeeDetails")
    @GetMapping("/employee/displayEmployee")
    public ModelAndView displayEmployee(ModelAndView modelAndView) {
        modelAndView.setViewName("displayEmployee");
        List<Employee> listEmployee = employeeService.getAllEmployee();
        modelAndView.addObject("listEmployee", listEmployee);
        return modelAndView;
    }

    //@PostMapping("/employee/rest/add")
    @GetMapping("/employee/addEmployee")
    public ModelAndView addEmployee(ModelAndView modelAndView) {
        modelAndView.addObject("command", new Employee());
        modelAndView.setViewName("addEmployee");
        return modelAndView;
    }

    @PostMapping("/employee/addEmployee/save")
    public String saveEmployee(@ModelAttribute("emp") Employee emp) {
        employeeService.addOrUpdateEmployee(emp);
        return "redirect:/employee/displayEmployee";
    }

    @GetMapping("/employee/getEmployee")
    public ModelAndView getEmployee(ModelAndView modelAndView) {
        modelAndView.setViewName("getEmployee");
        return modelAndView;
    }

    @GetMapping("/employee/getEmployeeByName")
    public String getEmployeeByName(@RequestParam("empName") String empName) {
        return "redirect:/employee/get/" + empName;
    }

    @GetMapping("/employee/deleteEmployee")
    public ModelAndView deleteEmployee(ModelAndView modelAndView) {
        modelAndView.setViewName("deleteEmployee");
        return modelAndView;
    }

    @GetMapping("/employee/deleteEmployeeById")
    public String deleteEmployeeById(@RequestParam("empId") long empId) {
        employeeService.deleteEmployeeById(empId);
        return "redirect:/home";
    }

    @GetMapping("/employee/updateEmployee/{empId}")
    public ModelAndView updateEmployeeById(@PathVariable("empId") long empId, ModelAndView modelAndView) {
        Employee employee = employeeService.getEmployeeById(empId);
        modelAndView.addObject("employee", employee);
        modelAndView.addObject("command", employee);
        modelAndView.setViewName("editEmployee");
        return modelAndView;
    }

    @RequestMapping(value = "/employee/updateEmployee", method = RequestMethod.POST)
    public String employeeUpdate(@ModelAttribute("emp") Employee emp) {
        employeeService.addOrUpdateEmployee(emp);
        return "redirect:/home";
    }
}
