package com.java.ajay.springboot.controller;

import com.java.ajay.springboot.model.Employee;
import com.java.ajay.springboot.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class EmployeeRestController {

    @Autowired
    EmployeeService employeeService;

    @PostMapping("/employee/add")
    public Employee saveEmployee(@RequestBody Employee employee) {
        return employeeService.addOrUpdateEmployee(employee);
    }

    @ResponseBody()
    @GetMapping("/employee/get/{empName}")
    public Employee getEmployee(@PathVariable("empName") String empName) {
        return employeeService.getEmployeeByName(empName);
    }

    @GetMapping("/employee/all")
    public List<Employee> getAllEmployee() {
        return employeeService.getAllEmployee();
    }

    @PutMapping("/employee/update")
    public Employee updateEmployee(@RequestBody Employee employee) {
        return employeeService.addOrUpdateEmployee(employee);
    }

    @DeleteMapping("/employee/delete/{empId}")
    public Employee deleteEmployee(@PathVariable("empId") Long empId) {
        return employeeService.deleteEmployeeById(empId);
    }
}
