package com.java.ajay.springboot.service;

import com.java.ajay.springboot.dto.AuthenticationResponse;
import com.java.ajay.springboot.model.UserLogin;
import com.java.ajay.springboot.repository.UserLoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserLoginService {

    @Autowired
    UserLoginRepository loginRepo;

    @Autowired
    AuthenticationManager authManager;

    @Autowired
    JWTService jwtService;

    BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);

    public long findMaxUserId() {
        Optional<Long> maxId = loginRepo.findMaxUserId();
        System.out.println("User maxId = " + maxId);
        return maxId.orElse(1L);
    }

    public UserLogin saveUserLogin(UserLogin userLogin) {
        String encryptPass = encoder.encode(userLogin.getPassword());
        userLogin.setPassword(encryptPass);
        return loginRepo.save(userLogin);
    }

    public Object verify(UserLogin userLogin) {

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(userLogin.getUserName(), userLogin.getPassword());
        Authentication authentication = authManager.authenticate(token);

        AuthenticationResponse response = new AuthenticationResponse();
        response.setExpires_in(1800);
        response.setAccess_token(jwtService.generateToken(userLogin.getUserName()));

        return authentication.isAuthenticated() ?
                response : "Failed";
    }

}
