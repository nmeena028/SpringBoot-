package com.java.ajay.springboot.exception;

public class UserValidationException extends RuntimeException {
    public UserValidationException(String error) {
        super(error);
    }
}
