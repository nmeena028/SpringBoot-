package com.java.ajay.springboot.repository;

import com.java.ajay.springboot.model.Employee;
import org.springframework.data.repository.CrudRepository;

public interface EmployeeRepository extends CrudRepository<Employee, Long> {
    Employee findByEmpName(String empName);
}
