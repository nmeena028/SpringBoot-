package com.java.ajay.springboot.service;

import com.java.ajay.springboot.model.UserLogin;
import com.java.ajay.springboot.repository.UserLoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import static java.util.Objects.isNull;

@Service
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    UserLoginRepository loginRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        UserLogin userLogin = loginRepo.findByUserName(username);

        if (isNull(userLogin)) {
            System.out.println("User Not Found : " + username);
            throw new UsernameNotFoundException("User Not Found : " + username);
        }

        return new UserSecurityService(userLogin);
    }
}
