package com.java.ajay.springboot.controller;

import com.java.ajay.springboot.model.UserLogin;
import com.java.ajay.springboot.service.UserLoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;

@RestController
public class UserLoginController {

    @Autowired
    UserLoginService loginService;

    @GetMapping("/users/register")
    public ModelAndView registerUser(ModelAndView modelAndView) {

        long maxUserId = loginService.findMaxUserId();
        UserLogin userLogin = new UserLogin();
        userLogin.setUserId(maxUserId + 1);

        modelAndView.setViewName("registerUser");
        modelAndView.addObject("command", userLogin);
        return modelAndView;
    }

    @PostMapping(value = "/users/saveUserLogin")
    public ModelAndView registerUserSave(@ModelAttribute("user") @Valid UserLogin userLogin) {
        userLogin = loginService.saveUserLogin(userLogin);
        System.out.println("Saved UserLogin = " + userLogin);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("redirect:/home");
        return modelAndView;
    }

    @PostMapping(value = "/myLogin")
    public Object loginUser(@RequestBody @Valid UserLogin userLogin) {
        return loginService.verify(userLogin);
    }
}
