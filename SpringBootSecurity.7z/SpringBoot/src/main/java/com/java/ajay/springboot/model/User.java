package com.java.ajay.springboot.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "SB_USER")
public class User {

    @Id
    @Column(name = "USER_ID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long userId;

    @NotNull(message = "User Name Cannot Be Null")
    @NotBlank(message = "User Name Cannot Be Blank")
    @Column(name = "USER_NAME")
    private String userName;

    @Column(name = "ADDRESS")
    private String address;

    @Pattern(regexp = "[0-9]+", message = "Phone Should Be Digits Only") //\d
    @Column(name = "PHONE")
    private String phone;

    @Email(message = "Invalid Email ID")
    @Column(name = "EMAIL_ID")
    private String emailId;
}
