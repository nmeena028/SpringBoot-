package com.java.ajay.springboot.service;

import com.java.ajay.springboot.exception.UserValidationException;
import com.java.ajay.springboot.model.User;
import com.java.ajay.springboot.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static java.util.Objects.nonNull;

@Service
public class UserService {

    @Autowired
    UserRepository userRepository;

    @Autowired
    Validator validator;

    public User saveOrUpdateUser(User user) {
        User newUser = userRepository.save(user);
        System.out.println("New User = " + newUser);
        return newUser;
    }

    public List<User> getAllUsers() {
        System.out.println("Get All Employee...");
        List<User> listUsers = new ArrayList<>();
        userRepository.findAll().forEach(listUsers::add);
        return listUsers;
    }

    public void validateUser(User user) {
        Set<ConstraintViolation<User>> violations = validator.validate(user);
        if (nonNull(violations) && !violations.isEmpty()) {
            String errors = violations.stream()
                    .map(ConstraintViolation::getMessage)
                    .distinct().collect(Collectors.joining(", "));

            System.out.println("Validation Error = " + errors);

            throw new UserValidationException(errors);
        }
        System.out.println("User Validated Successfully.");
    }

}
