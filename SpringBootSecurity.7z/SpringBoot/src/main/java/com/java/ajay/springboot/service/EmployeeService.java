package com.java.ajay.springboot.service;

import com.java.ajay.springboot.exception.EmployeeNotFoundException;
import com.java.ajay.springboot.repository.EmployeeRepository;
import com.java.ajay.springboot.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.nonNull;

@Service
public class EmployeeService {

    @Autowired
    EmployeeRepository empRepository;

    public Employee addOrUpdateEmployee(Employee employee) {
        Employee newEmployee = empRepository.save(employee);
        System.out.println("New Employee = " + newEmployee);
        return newEmployee;
    }

    public Employee getEmployeeByName(String empName) {
        System.out.println("Get Employee By Name = " + empName);
        Employee employee = empRepository.findByEmpName(empName);
        System.out.println("Found Employee = " + employee);
        return employee;
    }

    public Employee getEmployeeById(Long empId) {
        return empRepository.findById(empId).stream().findFirst().orElse(null);
    }

    public List<Employee> getAllEmployee() {
        System.out.println("Get All Employee...");
        List<Employee> employeeList = new ArrayList<>();
        empRepository.findAll().forEach(employeeList::add);
        return employeeList;
    }

    public Employee deleteEmployeeById(Long empId) {
        Employee employee = getEmployeeById(empId);
        if (nonNull(employee)) {
            empRepository.deleteById(empId);
            System.out.println("Employee Deleted = " + employee);
        }
        throw new EmployeeNotFoundException("Employee Not Found, EmpId : " + empId);
    }
}
