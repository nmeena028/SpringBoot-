package com.java.ajay.springboot.controller;

import com.java.ajay.springboot.model.User;
import com.java.ajay.springboot.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;

@Controller
public class UserController {

    @Autowired
    UserService userService;

    @RequestMapping(value = "/users", method = RequestMethod.GET)
    public ModelAndView displayUsers(ModelAndView modelAndView) {
        modelAndView.setViewName("displayUser");
        List<User> listUsers = userService.getAllUsers();
        modelAndView.addObject("listUsers", listUsers);
        return modelAndView;
    }

    @RequestMapping(value = "/users/addUser", method = RequestMethod.GET)
    public ModelAndView addUser(ModelAndView modelAndView) {
        modelAndView.setViewName("addUser");
        modelAndView.addObject("command", new User());
        return modelAndView;
    }

    @RequestMapping(value = "/users/saveUser", method = RequestMethod.POST)
    public String saveUser(/*@Valid*/ @ModelAttribute("user") User user) {
        userService.validateUser(user);
        User newUser = userService.saveOrUpdateUser(user);
        System.out.println("New User Added = " + newUser);
        return "redirect:/users";
    }

}
