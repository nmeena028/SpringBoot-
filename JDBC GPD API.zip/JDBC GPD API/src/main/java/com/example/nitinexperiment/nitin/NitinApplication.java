package com.example.nitinexperiment.nitin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NitinApplication implements CommandLineRunner {



//	@Autowired
//	DB Db;

	public static void main(String[] args) {

		SpringApplication.run(NitinApplication.class, args);
	}

	@Override
	public void run(String... args){
		System.err.println("hello");
	}

   

}
