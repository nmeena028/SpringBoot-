package com.example.nitinexperiment.nitin;


public class DevDB implements DB {
    public String getdata()
    {
        return "Dev Data";
    }

}
