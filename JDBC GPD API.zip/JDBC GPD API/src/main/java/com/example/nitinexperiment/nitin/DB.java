package com.example.nitinexperiment.nitin;


public interface DB{
     
    public String getdata();
}
