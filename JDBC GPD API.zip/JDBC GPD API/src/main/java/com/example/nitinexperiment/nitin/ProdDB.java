package com.example.nitinexperiment.nitin;

public class ProdDB implements DB{

    public String getdata(){
        return "Prod Data";
    }
}
