package com.example.nitinexperiment.nitin.dto;

import com.example.nitinexperiment.nitin.Entity.employeeEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class employeeDTO {

    private Long Id;
    private String Name;
    private LocalDate DateOfJoining;
    @JsonProperty("Active")
    private boolean Active;


    public static employeeEntity getById(Long id) {
        return null;
    }
}
