package com.example.nitinexperiment.nitin;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Configuration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;



@Configuration
public class appconfigure{


    @Bean
    @ConditionalOnProperty(name="project.mode", havingValue ="production")
    public ProdDB getProdDBBean(){
        return new ProdDB();
    }

    @Bean
    @ConditionalOnProperty(name="project.mode", havingValue ="development ")
    public DB getDevDBBean(){
        return new DevDB();
    }

    @Bean
    public ModelMapper getmodelmapper(){
        return new ModelMapper();
    }
   
}
