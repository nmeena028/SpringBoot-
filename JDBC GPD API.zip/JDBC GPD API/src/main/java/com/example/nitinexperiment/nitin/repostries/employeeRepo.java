package com.example.nitinexperiment.nitin.repostries;

import com.example.nitinexperiment.nitin.Entity.employeeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface employeeRepo extends JpaRepository<employeeEntity,Long> {

}
