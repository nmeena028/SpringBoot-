package com.example.nitinexperiment.nitin.service;



import com.example.nitinexperiment.nitin.Entity.employeeEntity;
import com.example.nitinexperiment.nitin.dto.employeeDTO;
import com.example.nitinexperiment.nitin.repostries.employeeRepo;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class employeeService {


    static employeeRepo employeeRepo;
    static ModelMapper modelMapper;


    public employeeService(employeeRepo employeeRepo,
                           ModelMapper modelMapper) {
        this.employeeRepo = employeeRepo;
        this.modelMapper=modelMapper;
    }

    public static List<employeeDTO> getAllemployee() {
         return employeeRepo.findAll()
                            .stream()
                            .map(employeeEntity -> modelMapper.map(employeeEntity, employeeDTO.class))
                            .collect(Collectors.toList());
    }

//    public static List<employeeDTO> getAllemployee() {
//        return employeeRepo.findAll()
//                .stream()
//                .map(employeeEntity -> modelMapper.map(employeeEntity, employeeDTO.class))
//                .collect(Collectors.toList());
//    }

    //entity to dto convertion
    @Deprecated
    public employeeDTO getemployeeId(Long Id){
        employeeEntity employeeEntity= employeeRepo.getById(Id);
        return modelMapper.map(employeeEntity,employeeDTO.class);

//        return new employeeDTO(employeeEntity.getId(), employeeEntity.getName(),employeeEntity.getDateOfJoining(),employeeEntity.isActive());
    }


    public employeeDTO createNewEmployee(employeeDTO employeeDTO) {
        employeeEntity employeeEntity=modelMapper.map(employeeDTO,com.example.nitinexperiment.nitin.Entity.employeeEntity.class);
       return modelMapper.map(employeeRepo.save(employeeEntity),employeeDTO.class);
    }



    public boolean deleteEmployeeById(Long id) {
       boolean ispresent= employeeRepo.existsById(id);
       if(!ispresent) return false;

       employeeRepo.deleteById(id);
       return true;



    }



}
