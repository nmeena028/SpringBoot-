package com.example.nitinexperiment.nitin.contoller;

import com.example.nitinexperiment.nitin.dto.employeeDTO;
import com.example.nitinexperiment.nitin.service.employeeService;
//import jakarta.websocket.server.PathParam;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping(path="/employee")
public class employeeController {


    private final employeeService employeeservice;

    public employeeController(employeeService employeeservice) {
        this.employeeservice = employeeservice;
    }

    @GetMapping
    public  List<employeeDTO> getAllemployee(){
        return employeeService.getAllemployee();
    }


    @GetMapping(path="/{id}")
    public employeeDTO getEmployeeById(@PathVariable("id") Long employeeid){
        return employeeservice.getemployeeId(employeeid);
    }


    @PostMapping
    public employeeDTO createnewemp(@RequestBody employeeDTO employeeDTO ){
        return employeeservice.createNewEmployee(employeeDTO);
    }

    @DeleteMapping(path="/{id}")
    public boolean deleteEmployeeById(@PathVariable Long id){
       return employeeservice.deleteEmployeeById(id);

    }





//    @GetMapping(path ="/{id}")
//    public employeeDTO getemployee(@PathVariable("id") long employeesId  ) {
//        return new employeeDTO(employeesId,"nitin", LocalDate.of(2025, 8, 2), true);
//    }
//
//
//    @GetMapping
//    public String getMethodName(@PathParam("sortby") String sortby,
//                                @PathParam("limit") Integer limit) {
//
//        return "HELLO "+ sortby +" "+ limit ;
//
//    }

}
